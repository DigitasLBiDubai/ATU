
var loginPage = {

    template:
    '<div class="page center">' +
        '<header><span class="centerlogo" title="DigitasLBi"></span></header>' +
        '<div class="body">' +
            '<div class="login-form">' +
            '<h1>{{name}}</h1>' +
                '<form id="login-form">' +
                    '<div class="form-input">' +
                        '<input id="username" type="text" name="username" value="otavio" />' +
                    '</div>' +
                    '<div class="form-input">' +
                        '<input id="password" type="text" name="password" value="aaa" />' +
                    '</div>' +
                    '<div class="form-input">' +
                        '<a id="login-button" href="#" class="btn">Login</a>' +
                    '</div>' +
                '</form>' +
            '</div>' +
        '</div>' +
        '<footer>' +
        '</footer>' +
    '</div>',
}